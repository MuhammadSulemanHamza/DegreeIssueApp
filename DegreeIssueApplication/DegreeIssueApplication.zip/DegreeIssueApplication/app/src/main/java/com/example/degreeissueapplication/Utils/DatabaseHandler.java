package com.example.degreeissueapplication.Utils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;

import androidx.annotation.RequiresApi;

import com.example.degreeissueapplication.Model.DegreeIssueModel;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHandler extends SQLiteOpenHelper {

    private static final int VERSION = 1;
    private static final String DB_NAME = "DegreeIssueDatabase";
    private static final String APPLICATION_TABLE = "application";
    private static final String ID = "id";
    private static final String DEGREE = "degree";
    private static final String SESSION = "session";
    private static final String ROLL_NUMBER = "rollNumber";
    private static final String BATCH = "batch";
    private static final String DEPARTMENT = "department";
    private static final String REGISTRATION_NUMBER = "registrationNum";
    private static final String REASON = "reason";
    private static final String REV_FROM = "rev_from";
    private static final String REV_TO = "rev_to";
    private static final String CANDIDATE_NAME = "candidateName";
    private static final String CNIC = "cnic";
    private static final String FATHER_NAME = "fatherName";
    private static final String CGPA = "cgpa";
    private static final String DOB = "dob";
    private static final String INSTITUTE = "institute";
    private static final String ADDRESS = "address";
    private static final String CONTACT = "contact";
    private static final String CREATE_APPLICATION_TABLE = "CREATE TABLE " + APPLICATION_TABLE +
            "(" + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "+
            DEGREE + " TEXT, " +
            SESSION + " TEXT, " +
            ROLL_NUMBER + " TEXT, " +
            BATCH + " TEXT, " +
            DEPARTMENT + " TEXT, " +
            REGISTRATION_NUMBER + " TEXT, " +
            REASON + " TEXT, " +
            REV_FROM + " TEXT, " +
            REV_TO + " TEXT, " +
            CANDIDATE_NAME + " TEXT, " +
            CNIC + " TEXT, " +
            FATHER_NAME + " TEXT, " +
            CGPA + " TEXT, " +
            DOB + " TEXT, " +
            INSTITUTE + " TEXT, " +
            ADDRESS + " TEXT, " +
            CONTACT + " INTEGER)";

    private SQLiteDatabase db;

    public DatabaseHandler(Context context) {
        super(context, DB_NAME, null, VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_APPLICATION_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table
        db.execSQL("DROP TABLE IF EXISTS " + APPLICATION_TABLE);

        //Create tables again
        onCreate(db);
    }

    public void openDataBase(){
        db = this.getWritableDatabase();
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void insertApplication(DegreeIssueModel application) {
        ContentValues cv = new ContentValues();
        cv.put(DEGREE, application.getDegree());
        cv.put(SESSION, application.getSession());
        cv.put(ROLL_NUMBER, application.getRollNumber());
        cv.put(BATCH , application.getBatch());
        cv.put(DEPARTMENT, application.getDepartment());
        cv.put(REGISTRATION_NUMBER, application.getRegNum());
        cv.put(REASON , application.getReason());
        cv.put(REV_FROM, application.getRev_from());
        cv.put(REV_TO , application.getRev_to());
        cv.put(CANDIDATE_NAME, application.getCandidateName());
        cv.put(CNIC, application.getCnic());
        cv.put(FATHER_NAME, application.getFatherName());
        cv.put(CGPA, application.getCgpa());
        cv.put(DOB, application.getDob());
        cv.put(INSTITUTE, application.getInstitute());
        cv.put(ADDRESS, application.getAddress());
        cv.put(CONTACT, application.getContact());
        db.insert(APPLICATION_TABLE, null, cv);
    }

    public List<DegreeIssueModel> getAllApplications(){
        List<DegreeIssueModel> appList = new ArrayList<>();
        Cursor cur = null;

        db.beginTransaction();

        try {
            cur = db.query(APPLICATION_TABLE, null, null, null,
                    null, null, null, null);
            if (cur != null) {
                if (cur.moveToFirst()) {
                    do {
                        DegreeIssueModel applications = new DegreeIssueModel();
                        applications.setId(cur.getInt(cur.getColumnIndex(ID)));
                        applications.setDegree(cur.getString(cur.getColumnIndex(DEGREE)));
                        applications.setSession(cur.getString(cur.getColumnIndex(SESSION)));
                        applications.setRollNumber(cur.getString(cur.getColumnIndex(ROLL_NUMBER)));
                        applications.setBatch(cur.getString(cur.getColumnIndex(BATCH)));
                        applications.setDepartment(cur.getString(cur.getColumnIndex(DEPARTMENT)));
                        applications.setRegNum(cur.getString(cur.getColumnIndex(REGISTRATION_NUMBER)));
                        applications.setReason(cur.getString(cur.getColumnIndex(REASON)));
                        applications.setRev_from(cur.getString(cur.getColumnIndex(REV_FROM)));
                        applications.setRev_to(cur.getString(cur.getColumnIndex(REV_TO)));
                        applications.setCandidateName(cur.getString(cur.getColumnIndex(CANDIDATE_NAME)));
                        applications.setCnic(cur.getString(cur.getColumnIndex(CNIC)));
                        applications.setFatherName(cur.getString(cur.getColumnIndex(FATHER_NAME)));
                        applications.setCgpa(cur.getString(cur.getColumnIndex(CGPA)));
                        applications.setDob(cur.getString(cur.getColumnIndex(DOB)));
                        applications.setInstitute(cur.getString(cur.getColumnIndex(INSTITUTE)));
                        applications.setAddress(cur.getString(cur.getColumnIndex(ADDRESS)));
                        applications.setContact(cur.getString(cur.getColumnIndex(CONTACT)));
                        appList.add(applications);
                    } while (cur.moveToNext());
                }
            }
        } finally {
          db.endTransaction();
          cur.close();
        }
        return appList;
    }

    public void updateStatus(int id, int status){
        ContentValues cv = new ContentValues();
        //cv.put(STATUS, status);
        //db.update(TODO_TABLE, cv, ID + "=?", new String[]{String.valueOf(id)});
    }

    public void updateTask(int id, String task){
        ContentValues cv = new ContentValues();
        //cv.put(TASK, task);
        //db.update(TODO_TABLE, cv, ID + "=?", new String[]{String.valueOf(id)});
    }

    public void updateDate(int id, String date){
        ContentValues cv = new ContentValues();
        //cv.put(DATE, date);
        //db.update(TODO_TABLE, cv, ID + "=?", new String[]{String.valueOf(id)});
    }

    public void updateCategory(int id, String cat){
        ContentValues cv = new ContentValues();
        //cv.put(CATEGORY, cat);
        //db.update(TODO_TABLE, cv, ID + "=?", new String[]{String.valueOf(id)});
    }

    public void deleteTask(int id){
        //db.delete(TODO_TABLE, ID + "=?", new String[]{String.valueOf(id)});
    }
    public void del()
    {
        db.execSQL("DROP TABLE IF EXISTS " + APPLICATION_TABLE);
        //onCreate(db);
    }

}
